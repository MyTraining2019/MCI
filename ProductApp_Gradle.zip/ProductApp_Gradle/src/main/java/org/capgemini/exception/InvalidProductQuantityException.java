package org.capgemini.exception;

public class InvalidProductQuantityException extends Exception {
	public InvalidProductQuantityException(){
		
	}
}
